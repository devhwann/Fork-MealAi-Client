export interface ChangePasswordType {
	current_password: string;
	change_password: string;
}

export interface CheckPasswordType {
	password: string;
}
