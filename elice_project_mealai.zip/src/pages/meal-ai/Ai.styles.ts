import styled from "styled-components";

export const GradientWrapper = styled.div`
	height: 100%;
	background: linear-gradient(180deg, #edfbf4 0%, rgba(237, 251, 244, 0) 100%);
`;
